<?php 
require'./inc/header.php'
?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <style>
      /* For the container */
.container {
  margin-top: 20px;
}

/* For the table */
.table {
  width: 100%;
  border-collapse: collapse;
}

/* For table header */
.table th {
  background-color: #f2f2f2; /* Light gray */
  text-align: left;
  padding: 8px;
  color:blue;
}

/* For table data */
.table td {
  padding: 8px;
}

/* For alternating row colors */
.table tbody tr:nth-child(even) {
  background-color: #f9f9f9; /* Lighter gray */
}

/* For the 'Edit' and 'Delete' links */
.ttn-container a {
  margin-right: 8px;
  text-decoration: none;
  padding: 3px 8px;
  border-radius: 3px;
}

.successful {
  color: #28a745; /* Green */
  border: 1px solid #28a745;
}

.dangerous {
  color: #dc3545; /* Red */
  border: 1px solid #dc3545;
}

/* Hover effects for links */
.ttn-container a:hover {
  opacity: 0.8;
}
</style>
</head>

<body>

<div class="container my-4">
    <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>FIRST</th>
        <th>LAST</th>
        <th>USERNAME</th>
        <th>IMAGE</th>
      
      </tr>
    </thead>
    <tbody>
      <?php
        include "./inc/database.php";
        $sql = "select * from phpadmins";
        $result = $conn->query($sql);
        if(!$result){
          die("Invalid query!");
        }
        while ($row = $result->fetch(PDO::FETCH_ASSOC)) {
            echo "
          <tr>
            <th>{$row['user_id']}</th>
            <td>{$row['first_name']}</td>
            <td>{$row['last_name']}</td>
            <td>{$row['username']}</td>
            <td><img src='{$row['std_img']}' height='200px' width='200px'><td>
            <td>
            <div class='ttn-container'>
              <a class='successful' href='edit.php?user_id={$row['user_id']}'>Edit</a>
              <a class='dangerous' href='delete.php?user_id={$row['user_id']}'>Delete</a>
              </div>
            </td>
          </tr>
          ";
        }
        ?>
    </tbody>
  </table>
      </div>
    
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
  </body>
</html>
<?php
require './inc/footer.php';
?>