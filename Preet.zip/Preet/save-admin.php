<?php 
require'./inc/header.php'
?>

<?php
	// connection
	require './inc/database.php';
	// variables
	$first_name = $_POST['first_name'];
	$last_name = $_POST['last_name'];
	$username = $_POST['username'];
	$password = $_POST['password'];
	$confirm = $_POST['confirm'];
	// validate inputs
	$ok = true;

		if (empty($first_name)) {
			echo '<p>First name required</p>';
			$ok = false;
		}
		if (empty($last_name)) {
			echo '<p>Last name required</p>';
			$ok = false;
		}
		if (empty($username)) {
			echo '<p>Username required</p>';
			$ok = false;
		}
		if ((empty($password)) || ($password != $confirm)) {
			echo '<p>Invalid passwords</p>';
			$ok = false;
		}
	// decide if we are saving or not
	if ($ok){
		$password = hash('sha512', $password);
		if (isset($_FILES["uploadfile"])) {
			$filename = $_FILES["uploadfile"]["name"];
			$tempname = $_FILES["uploadfile"]["tmp_name"];
			$folder = "images/" . $filename;
			move_uploaded_file($tempname, $folder);
		} else {
			// Handle the case where the file is not uploaded
			$folder = null;
		}
		// set up the sql
		$sql = "INSERT INTO phpadmins (first_name, last_name, username, password,std_img) VALUES ('$first_name', '$last_name', '$username', '$password', '$folder');";
		$conn->exec($sql);
    echo '<section class="success-row">';
		echo '<div>';
		echo '<h3><center>Admin Saved</center></h3>';
		echo '</div>';
    echo '</section>';
		//disconnect
		$conn = null;
	}
	?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style>
 /* Form styles */
form {
  background-color: #f5f5f5;
  padding: 15px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  max-width: 300px;
  margin: 0 auto;
  text-align: center; /* Aligns form contents to center */
}

h3 {
  margin-top: 0;
  margin-bottom: 15px;
}

/* Input field styles */
.form-control {
  width: 100%; /* Make the input fields responsive */
  padding: 8px;
  margin-bottom: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box; /* Ensures padding doesn't affect width */
}

/* Submit button styles */
.btn {
  display: inline-block;
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  color: #fff;
  background-color: #343a40;
}

.btn:hover {
  opacity: 0.8;
}

</style>
</head>
<body>
<div class="col-sm-12 col-md-6 col-lg-6">
            <form method="post" action="./inc/validate.php">
                <h3>Log in!</h3>
                <!-- Form input fields for login -->
                <p><input class="form-control" name="username" type="text" placeholder="Username" required /></p>
                <p><input class="form-control" name="password" type="password" placeholder="Password" required /></p>
                <!-- Submit button for login -->
                <input class="btn btn-dark" type="submit" value="Login" />
            </form>
        </div>
  </main>
</body>
</html>
<?php 
require'./inc/footer.php'
?>