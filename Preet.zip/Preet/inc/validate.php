<?php 
require'header.php'
?>


<?php
//store the user inputs in variables and hash the password
$username = $_POST['username'];
$password = hash('sha512', $_POST['password']);

//connect to db
require 'database.php';

//set up and run the query
$sql = "SELECT user_id FROM phpadmins WHERE username = '$username' AND password = '$password'";
$result = $conn->query($sql);
//store the number of results in a variable
$count = $result -> rowCount();
//check if any matches found
if ($count == 1){
	echo 'Logged in Successfully.';
	foreach  ($result as $row){
		//access the existing session created automatically by the server
		session_start();
		//take the user's id from the database and store it in a session variable
		$_SESSION['user_id'] = $row['user_id'];
		//redirect the user
		Header('Location: ../display-person.php');
	}
}
else {
	echo '';
}
$conn = null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <style> 
/* Resetting default margin and padding */



/* Wrapper styles */
.wrapper {
  width: 300px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);

  text-align: center;
  margin: auto; /* Centering the wrapper */
}

/* Title-text styles */
.title-text {

}

/* Title styles */
.title {
  font-size: 22px;
  font-weight: bold;
  color: #333;
}

/* Login and Signup title styles */
.login,
.signup {
  margin-bottom: 15px;
  margin: auto; 
  text-align: center;
}
.form-inner
{
  text-align:center;
  margin: auto; 
}

/* Form-container styles */
.form-container {
  padding: 20px;
  text-align:center;
  margin: auto; 
}

/* Field styles */
.field {
  margin-bottom: 15px;
  text-align:center;
   
    padding-right:450px;
}

/* Input styles */
.field input {
  width: calc(100% - 22px); /* Adjusting input width */
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  text-align:center;
}

/* Pass-link styles */
.pass-link {

  margin-bottom: 15px;
padding-right:450px;
}

/* Submit button styles */
.btn-layer {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 8px;
  background: none; /* Remove the blue gradient */
  z-index: -1;
  transition: 0.5s;
}

.btn input[type="submit"] {
  background: #007bff; /* Set your desired button color */
  border: none;
  cursor: pointer;
  position: relative;
  z-index: 1;
  color: #fff;
  padding: 10px;
  border-radius: 4px;
  width: 100%;
}

.btn:hover .btn-layer {
  width: 0;
}



</style>
</head>
<body>

  <main>
  <div class="wrapper">
      <div class="title-text">
        <div class="title login">INVALID TRY AGAIN</div>
        <div class="title signup">Signup Form</div>
     
      <div class="form-container">
        <div class="form-inner">
        <form method="post" action="validate.php" class="login">
            <div class="field">
              <input type="text" placeholder="Username" name="username" required>
            </div>
            <div class="field">
              <input type="password" placeholder="Password" name="password" required>
            </div>
            <div class="pass-link"><a href="#">Forgot password?</a></div>
            <div class="field btn">
              <div class="btn-layer"></div>
              <input type="submit" value="Login">
            </div>
          </form>
  </main>
</body>
</html>
<br><br><br>
<?php 
require'footer.php'
?>