
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="stylesheet.css" >
  <title>Document</title>
</head>
<body>
    <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  
<footer>
<section class="personal-description" id="about"> 
        
    <div class="personal-description-container">
        <div class="personal-description-text">
            <h2 class="personal-description-title">About <br>Myself<br></h2>
            <p class="personal-description-body">Hello I’m a software developer! I can help you build a product , feature or website Look through some of my work and experience! If you like what you see and have a project you need coded, don’t hestiate to contact me.</p>
            <hx class ="personal-description-connect">LETS CONNECT</hx>
        </div>

        <ul class="social-media">
            <li class="social-media-item twitter"><a  href=""><img src="./assets/twitter.png" alt=""></a></li>
            <li class="social-media-item linkedin"><a  href=""><img  src="./assets/Linkedin icon.png" alt=""></a></li>
            <li class="social-media-item m-media"><a  href=""><img  src="./assets/m-icon.png" alt=""></a></li>
            <li class="social-media-item github"><a  href=""><img  src="./assets/git.png" alt=""></a></li>
            <li class="social-media-item unknown"><a  href=""><img  src="./assets/unknown.png" alt=""></a></li>
            

        </ul>
        <div class="box-button-description">
            <button class="btn-personal-description">Get my resume</button>
        </div>
    </div>


<!--here starts languages-->
 <div class="container-languages">
    <ul class="languages">
        <li class="txt-language active">languages</li>
         
        <div class="tech-list">
            <li class="language-technologies">
            <button class="language-technologies-button">
                <img src="./assets/js.png" alt="">
                <li class="txt-tech js"> javascript </li>
                <img id="icon"src="/assets/icon.png" alt="">
            </button> 
            </li>

            <li class="language-technologies">
            <button class="language-technologies-button">
                <img src="./assets/html.png" alt="">
                <li class="txt-tech html"> HTML </li>
                <img id="icon"src="/assets/icon.png" alt="">
            </button> 
            </li>

            <li class="language-technologies">
            <button class="language-technologies-button">
                <img src="./assets/css.png" alt="">
                <li class="txt-tech js"> CSS </li>
                <img id="icon"src="/assets/icon.png" alt="">
            </button> 
            </li>
        </div>
        
       
        
        <li class="txt-language frameworks"> frameworks </li>
        
        <hr>
        
        <li class="txt-language skills"> skills </li>

        <hr>
        
    </ul>
</div>


<!--here starts Contact form-->
<section class="contact-form" id="contact">

    <div class="form-container">
        <div class="form-text">
            <h2 class="form-title">contact me</h2>
            <p class="form-description">If you have an application you are interested in developing, a feature that you need built or a project that needs coding. I’d love to help with it </p>
        </div>
        <form class="form-contact" id="form" name ="form" action="https://formspree.io/f/mvonawkj"  method="POST" onsubmit="validationForm()">
          
                  <input class= "form-input" type="text" id="username" name="username" placeholder="type name" required maxlength="30" minlength = "5" required/>
               
                  <input class= "form-input" type="email" id="email" name="email" placeholder="type email" minlength = "5" required/>

                  <textarea class= "form-input" id="msg" name="user_message" placeholder="write your message here" maxlength="500" minlength = "5" required ></textarea>
                
            <div class="error" id="error"> Email should be written in lower case</div>
            <div class="box-button-contact">
                <button type="submit" class="btn-submit" >Get in touch</button>
            </div>
        </form> 
    </div>
   
</section>
</footer>

</body>
</html>