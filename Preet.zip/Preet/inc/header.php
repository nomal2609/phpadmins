<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="My First Portfolio">
    <title>Portafolio Main Page</title>
    <link rel="stylesheet" href= "modalweb.css">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="modal.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="stylesheet.css">
</head>

<body>
<!---Here starts Header Main Page-->
<header class="toolbar" id="toolbar" >
    
    <a class="brand" href="" id="brand">My logo</a>
    <nav class="navbar" id="navbar">
        <ul class="ul-navbartool" id="ul-demo">

            <li class="li-navbartool"> <a href="index.html" class="li-navbartool">index</a></li>
            <li class="li-navbartool"> <a href="details.php" class="li-navbartool">details</a></li>
            <li class="li-navbartool"> <a href="logout.php" class="li-navbartool">logout</a></li>

        </ul>
        <img class="union" src="./assets/Union.png" alt="union" id="union" onclick="openMenu()">
    </nav>
    
    <!--overlayout div-->
    <div class="OverlayoutNav" id="OverlayoutNav">
        
    </div>

</header>
<br><br><br><br>
</body>
</html>