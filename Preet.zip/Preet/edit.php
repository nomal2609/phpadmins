<?php
  include "./inc/database.php";
  $user_id="";
  $first_name="";
  $last_name="";
  $username="";

  $error="";
  $success="";

  if($_SERVER["REQUEST_METHOD"]=='GET'){
    if(!isset($_GET['user_id'])){
      header("location:details.php");
      exit;
    }
    $user_id = $_GET['user_id'];
    $sql = "SELECT * FROM phpadmins WHERE user_id = $user_id";
    $result = $conn->query($sql);
    $row = $result->fetch(PDO::FETCH_ASSOC);
    while(!$row){
      header("location:details.php");
      exit;
    }
    $first_name=$row["first_name"];
    $last_name=$row["last_name"];
    $username=$row["username"];

  }
  else{
    $user_id = $_POST["user_id"];
    $first_name=$_POST["first_name"];
    $last_name=$_POST["last_name"];
    $username=$_POST["username"];

    $sql = "update phpadmins set first_name='$first_name', last_name='$last_name', username='$username' where user_id='$user_id'";
    $result = $conn->query($sql);
    
  }
  
?>
<?php 
require'./inc/header.php'
?>
<!DOCTYPE html>
<html lang="en">
    <!--Starting of head tag-->
<head>
    <style>
        /* Style for the form container */
.col-lg-6 {
  /* Add your styling here */
  /* Example styles */
  width: 50%; /* Adjust width as needed */
  margin: auto;
}

/* Style for the card */
.card {
  /* Add your styling here */
  /* Example styles */
  border: 1px solid #ccc;
  border-radius: 5px;
  padding: 20px;
}

/* Style for the card header */
.card-header {
  /* Add your styling here */
  /* Example styles */
  background-color: #ffc107; /* Yellow */
  border-radius: 5px 5px 0 0;
  padding: 10px;
}

/* Style for the h1 inside card header */
.card-header h1 {
  /* Add your styling here */
  /* Example styles */
  color: white;
  text-align: center;
}

/* Style for labels */
label {
  /* Add your styling here */
  /* Example styles */
  font-weight: bold;
}

/* Style for inputs */
.form-control {
  /* Add your styling here */
  /* Example styles */
  width: 100%;
  padding: 8px;
  margin-bottom: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

/* Style for submit buttons */
.eaton {
  /* Add your styling here */
  /* Example styles */
  padding: 10px 20px;
  background-color: #007bff; /* Blue */
  color: white;
  text-decoration: none;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  margin-top: 10px;
  display: inline-block;
}

/* Style for the 'Cancel' link */
.eaton[name="cancel"] {
  /* Add your styling here */
  /* Example styles */
  background-color: #dc3545; /* Red */
  margin-left: 10px;
}

/* Hover effect for buttons and links */
.eaton:hover {
  /* Add your hover styling here */
  /* Example styles */
  opacity: 0.8;
}
</style>
</head>
<body>
    
<!-- Header Section -->


 <div class="col-lg-6 m-auto">
 
 <form method="post" >
 
 <br><br><div class="card">
 
 <div class="card-header bg-warning">
 <h1 class="text-white text-center">  Update Member </h1>
 </div><br>

 <input type="hidden" name="user_id" value="<?php echo $user_id; ?>" class="form-control"> <br>

 <label>First Name: </label>
 <input type="text" name="first_name" value="<?php echo $first_name; ?>" class="form-control"> <br>

 <label> Last Name: </label>
 <input type="text" name="last_name" value="<?php echo $last_name; ?>" class="form-control"> <br>

 <label> Username: </label>
 <input type="text" name="username" value="<?php echo $username; ?>" class="form-control"> <br>

 <input type="submit" class="eaton" value="Submit" href="details.php">
 <a  type="submit" class="eaton" name="cancel" href="details.php"> Cancel </a><br>

 </div>
 </form>
 </div>
</body>
</html>
<?php 
require './inc/footer.php';
?>