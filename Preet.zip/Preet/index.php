<?php 
require'./inc/header.php'
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Define character encoding -->
    <meta charset="UTF-8">
    <!-- Define viewport settings for responsive design -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Radio</title>
    <!-- Favicon - Uncomment and modify the line below to set your favicon -->
<!-- <link rel="icon" type="image/x-icon" href="radio.png"> -->
    <link rel="icon" type="image/x-icon" href="radio.png">

    <!-- Font Awesome CDN link for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css">
<style>
    /* Form section with two columns */
.form-row {
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}

/* Individual form columns */
.col-lg-6 {
  flex: 0 0 calc(50% - 10px);
  margin-bottom: 20px;
}

/* Form styles */
form {
  background-color: #fff;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); /* Adding a box shadow */
}

h3 {
  margin-top: 0;
  margin-bottom: 20px;
}

/* Input field styles */
.form-control {
  width: 100%;
  padding: 10px;
  margin-bottom: 15px;
  border: 1px solid #ccc;
  border-radius: 4px;
}

/* Submit button styles */
.btn {
  display: inline-block;
  padding: 10px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  color: #fff;
}

.btn-dark {
  background-color: #343a40; /* Dark gray */
}

/* Hover effect for buttons */
.btn:hover {
  opacity: 0.8;
}
</style>

</head>
<body>
<main>
    <!-- Form section with two columns -->
    <section class="form-row row">
        <!-- Sign-up form -->
        <div class="col-sm-12 col-md-6 col-lg-6">
            <form method="post" action="save-admin.php" enctype="multipart/form-data">

                <h3 >Sign up!</h3>
                <!-- Form input fields -->
                <p><input class="form-control" name="first_name" type="text" placeholder="First Name" required/></p>
                <p><input class="form-control" name="last_name" type="text" placeholder="last_name" required /></p>
                <p><input class="form-control" name="username" type="text" placeholder="username" required /></p>
                <p><input class="form-control" name="password" type="password" placeholder="Password" required /></p>
                <p><input class="form-control" name="confirm" type="password" placeholder="Confirm Password" required /></p>
                <input type="file" name="uploadfile">
                <!-- Submit button -->
                <input class="btn btn-dark" type="submit" name="submit" value="Register" />
            </form>
        </div>
        
        <!-- Login form -->
        <div class="col-sm-12 col-md-6 col-lg-6">
            <form method="post" action="./inc/validate.php">
                <h3>Log in!</h3>
                <!-- Form input fields for login -->
                <p><input class="form-control" name="username" type="text" placeholder="Username" required /></p>
                <p><input class="form-control" name="password" type="password" placeholder="Password" required /></p>
                <!-- Submit button for login -->
                <input class="btn btn-dark" type="submit" value="Login" />
            </form>
        </div>
    </section>
</main>
</body>
</html>
  <!-- Footer Section -->
  <?php
require './inc/footer.php';
?>